const tutorial = require('./tutorial');
console.log(tutorial);
console.log(tutorial.sum(4,6));
console.log(tutorial.PI);
console.log(new tutorial.TrainObject());




