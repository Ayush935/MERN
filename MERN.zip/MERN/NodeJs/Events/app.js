//Events module and EventsEmitter class

const EventEmitter = require('events');
const eventEmitter = new EventEmitter();

/*

eventEmitter.on('tutorial',()=>{
    console.log('Event tutorial is called')
});

eventEmitter.emit('tutorial');

*/


// pass on the parameter

eventEmitter.on('tutorial',(num1,num2)=>{
    console.log(num1+num2);
});

eventEmitter.emit('tutorial',1,2)

class Person extends EventEmitter{

    constructor(name){
        super();
        this._name = name;
    }

    get name(){
        return this._name;
    }

}

let pedro = new Person('pedro');
let christ = new Person('christ');

pedro.on('name',()=>{
    console.log('my name is '+ christ.name);
})

pedro.on('name',()=>{
    console.log('my name is '+ pedro.name);
})

pedro.emit('name');
christ.emit('name');

