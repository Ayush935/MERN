const fs = require('fs');

/*

fs.mkdir('tutorial',(err)=>{
    if(err)
        console.log(err);
    else 
        console.log('Folder succefully created');
        fs.rmdir('tutorial',(err)=>{
            if(err)
                console.log(err);
            else
                console.log('Folder Successfully deleted');
        })
})

*/

// fs.mkdir('tutorial',(err)=>{
//     if(err)
//         console.log(err);
//     else 
//         console.log('Folder successfully created');
//         fs.writeFile('./tutorial/example.txt','123455',(err)=>{
//             if(err)
//                 console.log(err);
//             else
//                 console.log('file successfully created');
//         })
// })

// fs.unlink('./tutorial/example.txt',(err)=>{
//     if(err)
//         console.log(err)
//     else
//         console.log('file successfully delete');
// })

// fs.rmdir('tutorial',(err)=>{
//     if(err)
//         console.log(err);
//     else
//         console.log('Folder successfully deleted');
// })

fs.readdir('example',(err,files)=>{
    if(err)
        console.log(err);
    else
        //console.log(files);
        for(let file of files){
            fs.unlink('./example/' + file,(err)=>{
                if(err)
                    console.log(err);
                else
                    console.log('file delted successfully');
            })
        }
})