const fs = require('fs');

//Create a file

fs.writeFile('example.txt',"This is example",(err)=>{
    if(err)
        console.log(err);
    else
        console.log("File successfully created");
        fs.readFile('example.txt','utf-8',(err,file)=>{
            if(err)
                console.log(err);
            else 
                console.log(file);
        })
})

fs.rename('example.txt','example1.txt',(err)=>{
    if(err)
        console.log(err);
    else
        console.log("File successfully renamed");
})

fs.appendFile('example1.txt',' some data added',(err)=>{
    if(err)
        console.log(err);
    else
        console.log("Successfully appended the file ");
})

fs.unlink('example1.txt',(err)=>{
    if(err)
        console.log(err);
    else
        console.log('file successfully deleted');
})



