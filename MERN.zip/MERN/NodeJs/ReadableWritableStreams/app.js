const fs = require('fs');
// const port = 3000

const readSTream = fs.createReadStream('example.txt','utf-8');
readSTream.on('data',(chunk)=>{
    console.log(chunk);
})

